// /scripts/resultsPage.js
(function () {
  // avoid double init if script is included twice
  if (window.__FBL_RESULTS_INITED__) return;
  window.__FBL_RESULTS_INITED__ = true;

  // --- FIND THE REAL ROOT FOR THE RESULTS AREA ---
  let root =
    document.getElementById("results-list") ||
    document.querySelector(".results-container") ||
    document.getElementById("results-container") ||
    document.querySelector("main");

  if (!root) {
    console.warn(
      "resultsPage: no dedicated container found, using <body> as root."
    );
    root = document.body;
  }

  console.log("[FBL] resultsPage root:", root);

  // --- API base (aligned with predictionsPage.js) ---
  const API_USERS =
    (
      window.FBL_API_BASE ||
      (window.FBL_CFG && window.FBL_CFG.API_BASE) ||
      ""
    ).replace(/\/$/, "") + "/api/users.php";

  // --- league context (body[data-league] > path fallback) ---
  const leagueKey =
    (document.body && document.body.dataset && document.body.dataset.league) ||
    (() => {
      const p = location.pathname.toLowerCase();
      if (p.includes("/laliga/")) return "LALIGA";
      if (p.includes("/bundesliga/")) return "BUNDESLIGA";
      if (p.includes("/ligue1/")) return "LIGUE1";
      return "PREMIER_LEAGUE";
    })();

  const leagueInfo =
    (window.FBL &&
      window.FBL.LEAGUE_MAP &&
      window.FBL.LEAGUE_MAP[leagueKey]) || {
      name: leagueKey,
      totalRounds: "?",
    };

  // ---------- helpers ----------
  const esc = (s) =>
    String(s).replace(/[&<>"']/g, (m) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m])
    );

  const fmtKickoff = (iso) =>
    window.FBL && window.FBL.formatKickoffLocal
      ? window.FBL.formatKickoffLocal(iso)
      : iso
      ? new Date(iso).toLocaleString()
      : "";

  const fmtSaved = (iso) => (iso ? new Date(iso).toLocaleString() : "");

  function computePoints(predH, predA, finH, finA) {
    if (!Number.isFinite(finH) || !Number.isFinite(finA)) return null; // pending
    if (!Number.isFinite(predH) || !Number.isFinite(predA)) return 0;

    if (predH === finH && predA === finA) return 3; // exact

    const po = predH === predA ? 0 : predH > predA ? 1 : -1;
    const ro = finH === finA ? 0 : finH > finA ? 1 : -1;
    const pd = predH - predA;
    const rd = finH - finA;

    if (po === ro && pd === rd) return 2; // outcome + GD
    if (po === ro) return 1;
    return 0;
  }

  async function getSessionUser() {
    try {
      const r = await fetch(API_USERS + "?action=session", {
        credentials: "include",
      });
      const j = await r.json();
      if (j && j.success) {
        sessionStorage.setItem(
          "fbl_current_user",
          JSON.stringify(j.user || {})
        );
        return j.user || null;
      }
    } catch (e) {
      console.warn("resultsPage: session lookup failed", e);
    }
    try {
      return JSON.parse(sessionStorage.getItem("fbl_current_user") || "null");
    } catch {
      return null;
    }
  }

  async function fetchAllLeagueFixtures() {
    if (window.FBL && window.FBL.fetchFixturesForLeague) {
      try {
        const all = await window.FBL.fetchFixturesForLeague(leagueKey);
        const byId = {};
        (all || []).forEach((f) => {
          byId[String(f.id)] = f;
        });
        return byId;
      } catch (e) {
        console.warn("resultsPage: fetchFixturesForLeague failed", e);
      }
    }
    return {};
  }

  // relaxed matching for leagues (XML may use slightly different labels)
  function leaguesMatch(pLeagueRaw, leagueKeyRaw) {
    const pl = String(pLeagueRaw || "").toUpperCase();
    const lk = String(leagueKeyRaw || "").toUpperCase();
    if (!pl || !lk) return false;
    if (pl === lk) return true;

    if (lk.includes("PREMIER") && pl.includes("PREMIER")) return true;
    if (
      (lk.includes("LALIGA") || lk.includes("LA LIGA")) &&
      (pl.includes("LALIGA") || pl.includes("LA LIGA"))
    )
      return true;
    if (lk.includes("BUNDES") && pl.includes("BUNDES")) return true;
    if (lk.includes("LIGUE") && pl.includes("LIGUE")) return true;

    return false;
  }

  async function loadMyPredictionsForLeague() {
    try {
      const res = await fetch(API_USERS + "?action=get_my_predictions", {
        credentials: "include",
      });
      const j = await res.json();
      console.log("[FBL] get_my_predictions raw:", j);
      if (!j || !j.success) return [];
      return (j.predictions || []).filter((p) =>
        leaguesMatch(p.league, leagueKey)
      );
    } catch (e) {
      console.warn("resultsPage: get_my_predictions failed", e);
      return [];
    }
  }

  // Get matchday for a fixture + prediction, preferring the API fixture data
  function getMatchdayForPrediction(pred, fixturesById) {
    const f = fixturesById[String(pred.fixtureId)] || null;
    let md = null;

    if (f) {
      if (f.matchday != null) md = f.matchday;
      else if (f.roundNumber != null) md = f.roundNumber;
      else if (f.round && typeof f.round === "object") {
        if (f.round.roundNumber != null) md = f.round.roundNumber;
      } else if (typeof f.round === "string") {
        const m = f.round.match(/(\d+)/);
        if (m) md = m[1];
      }
    }

    if (md == null && pred.matchday != null) md = pred.matchday;
    if (md == null || md === "") return "?";
    return String(md);
  }

  // Ensure there is exactly ONE visible name + points row.
  function ensureUserRow(userName) {
    const rows = Array.prototype.slice.call(
      document.querySelectorAll(".user-info")
    );
    let row = rows.length ? rows[rows.length - 1] : null; // keep last

    // if nothing exists, create a fresh row just above the results root
    if (!row) {
      row = document.createElement("div");
      row.className = "user-info";
      row.innerHTML = `
        <span class="user-name"></span>
        <span class="points">Points: <span id="total-points">0</span></span>
      `;
      if (root.parentElement) {
        root.parentElement.insertBefore(row, root);
      } else {
        document.body.insertBefore(row, root);
      }
    }

    // remove any other .user-info rows, keep only this one
    rows.forEach((el) => {
      if (el !== row) el.remove();
    });

    // hide the element right above if it looks like the old user pill
    const prev = row.previousElementSibling;
    if (prev && /points/i.test(prev.textContent)) {
      prev.style.display = "none";
    }

    // set the name (prefer username from signup)
    const nameSpan =
      row.querySelector(".user-name") ||
      row.querySelector("[data-role='user-name']") ||
      row.querySelector("span");
    if (nameSpan) nameSpan.textContent = esc(userName || "Guest");

    // ensure the total-points span exists
    let totalSpan = row.querySelector("#total-points");
    if (!totalSpan) {
      totalSpan = document.createElement("span");
      totalSpan.id = "total-points";
      const pointsWrap = row.querySelector(".points") || row;
      if (pointsWrap) pointsWrap.appendChild(totalSpan);
    } else {
      totalSpan.textContent = "0";
    }

    return row;
  }

  function sectionHeaderHTML(matchday) {
    return `
      <section class="matches" data-matchday="${esc(String(matchday))}">
        <div class="matches-header">
          <h3>Matches - Matchday ${esc(String(matchday))} of ${esc(
            String(leagueInfo.totalRounds || "?")
          )}</h3>
          <span class="arrow">&gt;</span>
        </div>
        <div class="matches-list"></div>
      </section>
    `;
  }

  function cardHTML(i1, f, pred) {
    const savedAt = fmtSaved(pred.timestamp);
    const kickoff = fmtKickoff(f?.utcDate);

    const ph = Number.isFinite(pred?.home?.score) ? pred.home.score : "";
    const pa = Number.isFinite(pred?.away?.score) ? pred.away.score : "";

    const fh =
      typeof f?.score?.fullTime?.home === "number" ? f.score.fullTime.home : "";
    const fa =
      typeof f?.score?.fullTime?.away === "number" ? f.score.fullTime.away : "";

    return `
      <div class="match-card" data-fixture="${esc(String(pred.fixtureId))}">
        <div class="match-header">MATCH ${i1} · Saved: ${esc(savedAt)}</div>
        <p class="match-time">${esc(kickoff)}</p>

        <div class="teams">
          <div class="team team--home">
            <img class="team-logo home-logo" alt="${esc(
              pred.home?.name || ""
            )} logo">
            <p>${esc(pred.home?.name || "")}</p>
          </div>

          <div class="score-section">
            <p class="label">Your prediction</p>
            <div class="score-box">
              <span><input type="number" class="pred-home" value="${ph}" min="0" readonly /></span>
              <span>–</span>
              <span><input type="number" class="pred-away" value="${pa}" min="0" readonly /></span>
            </div>

            <p class="label">Final score</p>
            <div class="score-box">
              <span><input type="number" class="final-home" value="${fh}" min="0" readonly /></span>
              <span>–</span>
              <span><input type="number" class="final-away" value="${fa}" min="0" readonly /></span>
            </div>
          </div>

          <div class="team team--away">
            <img class="team-logo away-logo" alt="${esc(
              pred.away?.name || ""
            )} logo">
            <p>${esc(pred.away?.name || "")}</p>
          </div>
        </div>

        <p class="points-earned"></p>
      </div>
    `;
  }

  function attachLogos(cardEl, teamHome, teamAway) {
    const hl = cardEl.querySelector(".home-logo");
    const al = cardEl.querySelector(".away-logo");
    if (window.FBL && window.FBL.ensureLogo) {
      if (teamHome)
        window.FBL.ensureLogo({ id: teamHome.id, name: teamHome.name }, hl);
      if (teamAway)
        window.FBL.ensureLogo({ id: teamAway.id, name: teamAway.name }, al);
    }
  }

  function updatePointsForCard(cardEl) {
    const getScore = (selector) => {
      const el = cardEl.querySelector(selector);
      if (!el) return NaN;
      const v = el.value;
      if (v === "" || v == null) return NaN;
      const n = Number(v);
      return Number.isNaN(n) ? NaN : n;
    };

    const ph = getScore(".pred-home");
    const pa = getScore(".pred-away");
    const fh = getScore(".final-home");
    const fa = getScore(".final-away");

    const pts = computePoints(ph, pa, fh, fa); // null = match not yet played

    const line = cardEl.querySelector(".points-earned");
    if (line) line.textContent = pts === null ? "" : `Points: ${pts}`;
    return pts === null ? 0 : pts;
  }

  function updateTotalPoints() {
    let total = 0;
    document
      .querySelectorAll(".match-card")
      .forEach((el) => (total += updatePointsForCard(el)));
    const tp = document.getElementById("total-points");
    if (tp) tp.textContent = String(total);
  }

  // remove any stray static headers that are NOT inside our container
  function removeStaticMatchdayHeaders() {
    const container = document.getElementById("all-matchday-sections");
    document.querySelectorAll(".matches-header").forEach((hdr) => {
      if (!container || !container.contains(hdr)) {
        const sec = hdr.closest(".matches");
        if (sec) sec.remove();
        else hdr.style.display = "none";
      }
    });
  }

  async function render() {
    // 1) remove any existing static match sections INSIDE the root
    root.querySelectorAll(".matches").forEach((el) => el.remove());

    // 2) show a loading placeholder inside the root
    let loading = root.querySelector(".loading");
    if (!loading) {
      loading = document.createElement("div");
      loading.className = "loading";
      loading.textContent = "Loading…";
      root.appendChild(loading);
    } else {
      loading.textContent = "Loading…";
      loading.style.display = "block";
    }

    const user = await getSessionUser();
    const displayName =
      (user && (user.username || user.name || user.email)) || "Guest";

    // Single pill with username used at signup
    ensureUserRow(displayName);

    // Predictions for THIS league only
    let preds = await loadMyPredictionsForLeague();

    // 3) create/clear our own container inside root
    let container = root.querySelector("#all-matchday-sections");
    if (!container) {
      container = document.createElement("div");
      container.id = "all-matchday-sections";
      root.appendChild(container);
    }
    container.innerHTML = "";
    loading.style.display = "none";

    if (!preds.length) {
      container.innerHTML = `
        <section class="matches">
          <div class="matches-header">
            <h3>Matches - Matchday ? of ${esc(
              String(leagueInfo.totalRounds || "?")
            )}</h3>
            <span class="arrow">&gt;</span>
          </div>
          <div class="hint">You have no saved predictions for ${esc(
            leagueInfo.name
          )} yet.</div>
        </section>
      `;
      const tp = document.getElementById("total-points");
      if (tp) tp.textContent = "0";

      removeStaticMatchdayHeaders(); // remove the old top one
      return;
    }

    const fixturesById = await fetchAllLeagueFixtures();

    // sort predictions by kickoff time
    preds.sort((a, b) => {
      const fa = fixturesById[String(a.fixtureId)];
      const fb = fixturesById[String(b.fixtureId)];
      const ta = Date.parse(fa?.utcDate || 0);
      const tb = Date.parse(fb?.utcDate || 0);
      return ta - tb;
    });

    // group by real matchday from API so it matches index + predictions page
    const groups = {};
    preds.forEach((p) => {
      const md = getMatchdayForPrediction(p, fixturesById);
      (groups[md] = groups[md] || []).push(p);
    });

    const matchdays = Object.keys(groups).sort(
      (a, b) => Number(a) - Number(b)
    );

    matchdays.forEach((md) => {
      container.insertAdjacentHTML("beforeend", sectionHeaderHTML(md));
      const list = container.lastElementChild.querySelector(".matches-list");

      const arr = groups[md];
      arr.forEach((p, idx) => {
        const f = fixturesById[String(p.fixtureId)] || null;
        list.insertAdjacentHTML("beforeend", cardHTML(idx + 1, f, p));
        const cardEl = list.lastElementChild;
        attachLogos(cardEl, p.home, p.away);
      });
    });

    updateTotalPoints();
    removeStaticMatchdayHeaders(); // clean up any top static header
  }

  render();
})();
