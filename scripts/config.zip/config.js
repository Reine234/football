(function (global) { 
  const FBL = global.FBL || {};
// public/scripts/config.js  (frontend-only)
window.FBL_CFG = window.FBL_CFG || {};
// Point this to your PHP container’s exposed host:port
window.FBL_CFG.API_BASE = "http://localhost:8080";
window.FBL_CFG.APP_BASE = "http://localhost:5000";

// …your existing config…
  window.FBL_GOOGLE_CLIENT_ID =
    '80010607738-2rv8rb19g5geecp15rd8mo0gjbs35oq2.apps.googleusercontent.com';

  // We are now working with the *current* active season:
  // API-Football:

  // We'll pull fixtures from July 1, 2025 up to May 2026.
  // (Bundesliga usually ends a bit earlier in May, so we respect that.)

  const API_CONFIG = {
    SEASON: 2025,              // 2025/2026 season
    TIMEZONE: "Africa/Douala", // display reference (you can keep this)
  };

  // Each league we support
  const LEAGUE_MAP = {
    "PREMIER_LEAGUE": {
      id: 39,                        // API-Football league id (Premier League)
      name: "Premier League",
      folder: "premier",

      // date window for fixtures in this season
      startDate: "2025-07-01",
      endDate:   "2026-05-25",

      totalRounds: 38,

      // TheSportsDB fallback for this same season
      sdb: {
        leagueId:  "4328",           // English Premier League on TheSportsDB
        seasonStr: "2025-2026"
      }
    },

    "LALIGA": {
      id: 140,                      // API-Football league id (La Liga)
      name: "La Liga",
      folder: "laliga",

      startDate: "2025-07-01",
      endDate:   "2026-05-25",

      totalRounds: 38,

      sdb: {
        leagueId:  "4335",          // La Liga on TheSportsDB
        seasonStr: "2025-2026"
      }
    },

    "BUNDESLIGA": {
      id: 78,                       // API-Football league id (Bundesliga)
      name: "Bundesliga",
      folder: "bundesliga",

      startDate: "2025-07-01",
      endDate:   "2026-05-17",      // Bundesliga finishes a bit earlier in May

      totalRounds: 34,

      sdb: {
        leagueId:  "4331",          // Bundesliga on TheSportsDB
        seasonStr: "2025-2026"
      }
    },
  

  "LIGUE1": {
  id: 61,                       // API-Football league id (France Ligue 1)
  name: "Ligue 1",
  folder: "ligue1",

  // LFP/FFF "calendrier général": opening weekend Aug 16, 2025; closing weekend May 16, 2026.
  startDate: "2025-08-16",
  endDate:   "2026-05-17",

  totalRounds: 34,              // 18 teams -> 34 matchdays

  sdb: {
    leagueId:  "4334",          // TheSportsDB: Ligue 1
    seasonStr: "2025-2026"
  }
}
  };



  FBL.API_CONFIG = API_CONFIG;
  FBL.LEAGUE_MAP = LEAGUE_MAP;

  global.FBL = FBL;
})(window);
