// /scripts/auth.js
(function () {
  //
  // Base URLs (must be set by /scripts/config.js before this file loads)
  //   window.FBL_API_BASE  -> e.g. "http://localhost:8080"  (PHP/Apache)
  //   window.FBL_APP_BASE  -> e.g. "http://localhost:5000"  (your frontend)
  //
  const API_BASE  = (window.FBL_CFG && window.FBL_CFG.API_BASE) ? window.FBL_CFG.API_BASE : "";
const API_USERS = API_BASE + "/api/users.php";



  // -------- helpers --------
  async function apiPost(body) {
    const res = await fetch(API_USERS, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include", // send/receive cookie fbl_sid
      body: JSON.stringify(body),
    });
    const text = await res.text();
    try { return JSON.parse(text); }
    catch { throw new Error(`API not JSON (status ${res.status}). Body: ${text.slice(0,160)}…`); }
  }

  async function apiGet(q) {
    const res = await fetch(API_USERS + (q ? `?${q}` : ""), {
      method: "GET",
      headers: { "Accept": "application/json" },
      credentials: "include",
    });
    const text = await res.text();
    try { return JSON.parse(text); }
    catch { throw new Error(`API not JSON (status ${res.status}). Body: ${text.slice(0,160)}…`); }
  }

  function getPending() {
    try { return JSON.parse(sessionStorage.getItem("pending_predictions") || "[]"); }
    catch { return []; }
  }
  function clearPending() { sessionStorage.removeItem("pending_predictions"); }

  async function flushPendingIfAny() {
    const arr = getPending();
    if (!arr.length) return;
    for (const p of arr) {
      const r = await apiPost({ action: "save_prediction", prediction: p });
      if (!r || !r.success) throw new Error(r?.message || "Save failed");
    }
    clearPending();
  }

  function leagueFolderFromKey(key) {
    if (key === "LIGUE1") return "ligue1";
    if (key === "LALIGA") return "laliga";
    if (key === "BUNDESLIGA") return "bundesliga";
    return "premier";
  }

  // robust join for redirects
  function toAppUrl(next) {
    if (!next) return APP_BASE.replace(/\/$/,'') + "/";
    if (/^https?:\/\//i.test(next) || next.startsWith("//")) return next;    // absolute
    if (next.startsWith("/")) return APP_BASE.replace(/\/$/,'') + next;      // root-relative
    return APP_BASE.replace(/\/$/,'') + "/" + next.replace(/^\.?\//,'');     // relative
  }

  function redirectAfterAuth() {
    const url  = new URL(location.href);
    const next = url.searchParams.get("next");

    if (next) {
      location.href = toAppUrl(next);
      return;
    }
    // default → current league results
    const key    = sessionStorage.getItem("FBL_leagueKey") || "PREMIER_LEAGUE";
    const folder = leagueFolderFromKey(key);
    location.href = APP_BASE.replace(/\/$/,'') + `/${folder}/results.html`;
  }

  // -------- public API --------
  const FBL_AUTH = {
    // returns true if ok, throws Error on failure
    async signUp(username, email, password) {
      if (!username || !email || !password) throw new Error("Please complete all fields.");
      const r = await apiPost({ action: "signup", name: username, email, password });
      if (!r || !r.success) throw new Error(r?.message || "Signup failed");
      await flushPendingIfAny();
      sessionStorage.setItem("fbl_current_user", JSON.stringify({ email: userOrEmail || email }));

      return true;
    },

    async signIn(userOrEmail, password) {
      if (!userOrEmail || !password) throw new Error("Please complete all fields.");
      // server accepts action 'signin' or 'login' — we use 'login'
      const r = await apiPost({ action: "login", email: userOrEmail, password });
      if (!r || !r.success) throw new Error(r?.message || "Signin failed");
      await flushPendingIfAny();
      sessionStorage.setItem("fbl_current_user", JSON.stringify({ email: userOrEmail || email }));

      return true;
    },

    async signOut() {
  try { await apiPost({ action: "logout" }); } catch {}
  sessionStorage.removeItem("fbl_current_user");
  location.reload();
},

async hasSession() {
  try {
    const j = await apiGet("action=session");
    if (j && j.success) return true;
  } catch {}

  // 🟢 Fallback if session cookie not available
  const cached = sessionStorage.getItem("fbl_current_user");
  return !!cached;
},

    

    redirectAfterAuth,
    // compatibility alias (some of your pages may call this name)
    redirectToResultsForCurrentLeague: redirectAfterAuth,

    // -------- Google Identity --------
    _googleInitDone: false,
    _googleClientId: null,

    googleInitOnce() {
      if (this._googleInitDone) return;
      const el  = document.getElementById("g_id_onload");
      const cid = el?.dataset?.client_id || window.FBL_GOOGLE_CLIENT_ID || null;
      if (!cid) { console.warn("Google Client ID missing."); return; }

      this._googleClientId = cid;

      if (!window.google || !google.accounts || !google.accounts.id) {
        console.warn("Google Identity script not loaded yet.");
        return;
      }
      google.accounts.id.initialize({
        client_id: cid,
        callback: window.fblGoogleOneTap,   // defined below
        auto_select: false,
        cancel_on_tap_outside: true,
        context: "signin",
      });
      this._googleInitDone = true;
    },

    googlePrompt() {
      this.googleInitOnce();
      if (!window.google || !google.accounts || !google.accounts.id) {
        alert("Google sign-in not ready yet."); return;
      }
      google.accounts.id.prompt(); // One Tap / chooser
    },
  };

  window.FBL_AUTH = FBL_AUTH;

  // Global callback used by the Google script tag
  window.fblGoogleOneTap = async function (response) {
    try {
      const credential = response && (response.credential || response.id_token || response.idToken);
      if (!credential) throw new Error("No Google credential");
      const r = await apiPost({ action: "google_login", credential });
      if (!r || !r.success) throw new Error(r?.message || "Google sign-in failed");
      await flushPendingIfAny();
      sessionStorage.setItem("fbl_current_user", JSON.stringify({ email: userOrEmail || email }));

      FBL_AUTH.redirectAfterAuth();
    } catch (e) {
      alert(e.message || "Google sign-in failed");
    }
  };

  // Hook a visible Google button if you have one with id="g_id_signin"
  window.addEventListener("click", (e) => {
    const btn = e.target.closest && e.target.closest("#g_id_signin");
    if (!btn) return;
    e.preventDefault();
    FBL_AUTH.googlePrompt();
  });

  // Auto-warm Google init when the SDK is around
  window.addEventListener("load", () => {
    if (document.getElementById("g_id_onload")) {
      setTimeout(() => FBL_AUTH.googleInitOnce(), 200);
    }
  });
})();
